(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__23d73404._.css",
  "static/chunks/c21b4_@tanstack_query-devtools_build_f7942e96._.js",
  "static/chunks/node_modules__pnpm_68314c74._.js",
  "static/chunks/web_app_providers_index_tsx_120f4267._.js"
],
    source: "dynamic"
});
